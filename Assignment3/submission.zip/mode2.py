from typing import Tuple, List, Any

from landsites import Land
from data_structures.heap import MaxHeap
from data_structures.hash_table import LinearProbeTable

class Mode2Navigator:
    """
    Mode2Navigator is used for manage the adventuring strategy on different land sites.

    Approach:
    - Hash table is used in initialising the land sites. (Key: land sites' name, value: land object)
    - Each land sites have different name which fulfill the criteria as a key.
    - The ADT is used to insert all the land sites in a different position, so that when we got the same score in different land sites,
    we can use the position to differentiate them.
    - Max heap is used to arrange the land sites based on the score calculated.
    - By using max heap, we can have direct access to the max score land sites (get_max : O(logN), add: O(logN)).
    - Max heap is built by using bottom-up heap construction which requires O(N) and allow us to fulfill the complexity required.

    Methods:
        __init__ : Initialise the navigator with the number of adventurer teams.
        add_sites() : Stores and adds land sites (sites) to the object.
        simulate_day() :  Simulates a day of the game.
        compute_score() : compute the maximum/potential score of a land site.
        construct_score_data_structure() : construct the appropriate data structure(s) to organize the scores of all the land sites

    Example:
        sites = [Land("A", 200, 50), Land("B", 550, 160), Land("C", 400, 200)]
        nav = Mode2Navigator(5)  # __init__
        RETURN: NONE

        nav.add_sites(sites)
        RETURN: NONE
        # visualising the hash table created
            0: Key: A; Value: Land("A", 200, 50)
            1: Key: B; Value: Land("B", 550, 160)
            2: Key: C; Value: Land("C", 400, 200)

        res = nav.simulate_day(150)
        RETURN:[(Land(name='B', gold=0.0, guardians=0), 150), (Land(name='A', gold=0.0, guardians=0), 50), (Land(name='B', gold=0.0, guardians=0), 10), (None, 0), (None, 0)]
        Within this method, it involves the helper method as below:
            a) self.compute_score('A', 150)
            RETURN: 450.0, 50, 200.0 (representing: score, number of sent adventurers, reward)
            # This method would be repeatedly call to get the score.
            # It will then use that to create a tuple with (score, position, land_site name)
            # The tuple will be added into a list and use to construct a max heap.

            b) self.construct_score_data_structure(150)
            RETURN: MaxHeap with all the scores added.
            # visualising the max heap.
                    (515.625, 1, 'B')
                        /       \
            (450.0, 2, 'A')     (300.0, 3, 'C')

    Attributes:
        self.teams (int) : total number of adventurer teams
        self.sites (LinearProbeTable) : Store the land sites object

    """

    def __init__(self, n_teams: int) -> None:
        """
        Initialise the object and stores the number of adventurer teams n_teams in the game
        Args:
            n_teams (int) : total number of adventurer teams

        Complexity:
            Best and worst case: O(1)
            Explanation:
            - It only involves initialising Linear Probe Table and the self.teams, which both takes constant time operation.
        """
        self.teams = n_teams
        self.sites = LinearProbeTable()

    def add_sites(self, sites: list[Land]) -> None:
        """
        Stores and adds land sites (sites) to the object.
        Args:
            sites: a list of land sites object

        Complexity:
            Best and Worst case: O(S)
            where S is the length of the additional land sites (input sites) to be added.
            Explanation:
            - As stated, we are assuming all the land sites would not have the same name
            - The method would only involve adding the name into the hash table O(1)
            - The iteration would only depend on the size of the input sites O(N)
        """
        # key = land name; value = land object
        for land in sites:
            self.sites[land.get_name()] = land  # O(1)

    def simulate_day(self, adventurer_size: int) -> list[tuple[Land | None, int]]:
        """
        Method simulates a day of the game.
        Args:
            adventurer_size: the size of the adventurers for every team.

        Complexity:
            Best and Worst case: O(N+ K logN)
            N is the number of existing land sites
            K is the number of adventure teams participating in the game.

            Explanation:
            - constructing a max heap using the method self.construct_score_data_structure() requires O(N)
            (For details: refer to the complexity of self.construct_score_data_structure())
            - Iterate through the total number of adventurer team O(K)
            - In each iteration, heap method such as get_max() and add() requires O(logN), other methods and mathematical calculations requires only O(1)
            - Resulting in the complexity of the whole iteration O(K logN)
        """
        res = []
        score_heap = self.construct_score_data_structure(adventurer_size)  # O(N)

        # O(K logN)
        for _ in range(self.teams):
            team_adventurer_size = adventurer_size
            max_tuple = score_heap.get_max()    # O(log N)

            score, position, name = max_tuple
            land = self.sites[name]
            score, sent_adventurers, reward = self.compute_score(land, team_adventurer_size)
            if sent_adventurers == 0:
                res.append((None, 0))

            elif land.get_guardians() != 0:
                land.gold -= reward
                land.guardians = max(0, land.get_guardians() - sent_adventurers)
                res.append((land, sent_adventurers))
            new_score, _, _ = self.compute_score(land, adventurer_size)  # O(1)
            score_heap.add((new_score, position, name))    # O(logN)
        return res

    def compute_score(self, land: Land, adventurers: int) -> tuple[float, int, float]:
        """
        Compute the maximum potential score for a given land site based on the number of adventurers.
        Args:
            land: land site object
            adventurers: number of adventurers

        Complexity:
            Best and worst case: O(1)
            Explanation:
            No matter in any conditions, the method would only involve min() and mathematical operations,
            all the method involves would only be O(1).
        """
        if land.get_guardians() == 0:
            reward = land.get_gold()
            sent_adventurers = 0
        else:
            sent_adventurers = min(land.get_guardians(), adventurers)
            reward = min((sent_adventurers * land.get_gold()) / land.get_guardians(), land.get_gold())
        score = 2.5 * (adventurers - sent_adventurers) + reward
        print(land.name, score, reward)
        return score, sent_adventurers, reward

    def construct_score_data_structure(self, adventurers: int) -> MaxHeap:
        """
        Construct the max heap to organise the land sites based on their score.

        Args:
            adventurers: number of adventurers

        Complexity:
            Best and worst case: O(N) where N is the number of existing land sites
            Explanation:
            - Retrieving the keys from the self.sites (hash table) requires O(M) where M is the hash table's table size.
            - Iterate through the list which contains all the name of the land list requires O(N).
            - Build the max heap using bottom up construction requires O(N).
            - The overall would be O(M + 2N). Considering the dominating terms, O(2N) and drop the constant would result in the complexity O(N).
        """
        # use a max heap to store the score
        score_heap = MaxHeap(len(self.sites))
        score_list = []
        land_list = self.sites.keys()   # O(M) M is the hash table's table size

        # O(N)
        for name in land_list:
            position = self.sites.hash(name)
            land = self.sites[name]     # hash table get method O(1)
            score, _, _ = self.compute_score(land, adventurers)     # O(1)
            score_list.append((score, position, name))  # O(1)

        # bottom up construction - O(N)
        score_heap = score_heap.heapify(score_list)
        return score_heap


