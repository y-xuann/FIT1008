from landsites import Land
from data_structures.bst import BinarySearchTree


class Mode1Navigator:
    """
    Mode1Navigator is used for manage the adventuring strategy on different land sites.

    Approach:
        - Binary Search Tree (BST) is used to represent a list of land sites.
        - The key of the node will be the ratio of guardians by the gold.
        - This can be retrieved from a method defined in Land class - get_ratio()
        - The BST formed are arranged based on the ratio.
        - add method uses logN complexity which fulfill the requirements for initialising the class.
        - The in-order traversal will also be used to generate maximum reward.

    Methods:
        __init__ : Initialise the navigator with the land sites and the number of adventurers.
        select_sites : Select the land sites you desire to attack by sending the adventurers in order to get the max reward.
        select_sites_from_adventure_numbers : calculates the maximum amount of reward that can make with different adventurer numbers.
        update_site : Updates the state of a specific land site.

    Example:
            sites = [Land("A", 200, 50), Land("B", 550, 150), Land("C", 400, 200)]
            nav =  Mode1Navigator(sites, 500)   #__init__
            RETURN: NONE
            # visualising the created BST: (Key: guardians to gold ratio ; item: land object)
                                        Key: 0.25
                        Item: Land(name='A', gold=200, guardians=50)
                                                \
                                                Key: 0.5
                                        Item: Land(name='B', gold=550, guardians=150)
                                                    \
                                                    Key: 3.0
                                               Item: Land(name='C', gold=400, guardians=200)
            #In order traversal: A, B, C

            nav.select_sites()
            RETURN:[(Land(name='A', gold=200, guardians=50), 50), (Land(name='B', gold=550, guardians=150), 150), (Land(name='C', gold=400, guardians=200), 200)]
            # A list of tuple which contains the land object and the number of adventurers sent.

            nav.select_sites_from_adventure_numbers([65, 290, 600, 450])
            RETURN:[255.0, 930.0, 1150.0, 1150.0]
            # A list which shows the maximum amount of reward you can make with different adventurer numbers.

            nav.update_site(sites[2], 400, 1)
            RETURN: NONE
            # visualising the order of the updated BST:
                                        Key: 0.25
                        Item: Land(name='A', gold=200, guardians=50)
                                    /                       \
                                Key: 0.0025                 Key: 0.5
            Item: Land(name='C', gold=400, guardians=1)     Item: Land(name='B', gold=550, guardians=150)
            #In order traversal: C, A, B

    Attributes:
        sites (list[Land]) : The initial states of the land sites.
        adventurers (int) : The total number of adventurers.

    """

    def __init__(self, sites: list[Land], adventurers: int) -> None:
        """
        Initialise the Mode1Navigator objects.
        Args:
            sites (list[Land]) : The initial states of the land sites.
            adventurers (int) : The total number of adventurers.

        Complexity:
            Best and worst case: O(N * logN), where N is the number of land sites.
            Explanation:
            - It needs to insert N times based on the number of land sites into the BST created.
            - Inserting each element requires a complexity of O(logN).
        """
        self.sites = BinarySearchTree()     # O(1)

        # insert for N times, O(N log N)
        for land in sites:
            self.sites[land.get_ratio()] = land

        self.adventurers = adventurers

    def select_sites(self) -> list[tuple[Land, int]]:
        """
        Select the land sites you desire to attack. we must get the max reward
        Complexity:
            Best: O(1) Occurs when the number of adventurers provided is only enough for the first land.
            Explanation:
            - Even when there is a large number of land sites, the number of adventurers are only enough for thr first land site.
            - It will run the loop once and break in the second iteration.
            - This results in constant time operation.

            Worst: O(N) Occurs when all the land_sites have a positive ratio
            and the number of adventurers are enough to send for all the land sites.
            N is the number of land sites.
            Explanation:
            - When the number of adventurers provided are enough for all the land sites, it will iterate through the self.sites.
            - Since there is no early termination condition occurs, it will perform maximum iteration based on the number of the land sites.
            - In the iteration, all other operation such as append() and min() contributes O(1) complexity.
        """
        current_adventurers = self.adventurers
        res = []
        # iterate through the land sites O(N)
        for current_node in self.sites:
            land = current_node.item
            # check if there are remaining adventurers
            if current_adventurers == 0:
                break
            else:
                if land.get_ratio() == 0:
                    continue
                else:
                    # determine the number of adventurers that we should sent
                    adventurers_sent = min(land.get_guardians(), current_adventurers)
                    res.append((land, adventurers_sent))        # O(1)
                    current_adventurers -= adventurers_sent
        return res

    def select_sites_from_adventure_numbers(self, adventure_numbers: list[int]) -> list[float]:
        """
        calculates the maximum amount of reward you can make with different adventurer numbers.
        Args:
            adventure_numbers (list[int]) :  a list indicating the number of adventurers for each of the configuration

        Complexity:
            Best: O(A) Occurs when the number of adventurers provided is only enough for the first land.
            Explanation:
            - Even when there is a large number of land sites, the every number of adventurers in the list provided are only enough for the first land site.
            - The inner loop will only run once and break early in the second iteration of inner loop.
            - This results in constant time operation in the inner loop.
            - The outer loop will still need to traverse through the adventure_numbers list in any scenarios.

            Worst: O(A * N) Occurs when all the land_sites have a positive ratio
            and all the number in adventure_numbers list are enough for all the land sites.
            A is the length of the adventure_numbers. N is the number of land sites.
            Explanation:
            - When the number of adventurers is enough for all the land sites, the outer loop iterates through A adventure_numbers,
            and the inner loop iterates through all N land sites.
            - Since no early termination condition is met, it performs the maximum number of iterations in both loop.
            - During each iteration, operations such as append() and min() contribute O(1) complexity.
        """
        res = []
        # iterate through the adventure_numbers list O(A)
        for current_adventurers in adventure_numbers:
            total_reward = 0
            if current_adventurers == 0:
                res.append(total_reward)
                continue

            # iterate through the self.sites O(N)
            for current_node in self.sites:
                land = current_node.item
                # check if there are remaining adventurers
                if current_adventurers == 0:
                    break
                else:
                    if land.get_ratio() == 0:
                        continue
                    else:
                        # determine the number of adventurers that we should sent
                        adventurers_sent = min(land.get_guardians(), current_adventurers)
                        max_reward = min((adventurers_sent * land.get_gold()) / land.get_guardians(), land.get_gold())
                        total_reward += max_reward
                        current_adventurers -= adventurers_sent

            res.append(total_reward)
        return res

    def update_site(self, land: Land, new_reward: float, new_guardians: int) -> None:
        """
        update the state of the land object.

        Args:
            land (Land) : to be updated land object
            new_reward (float) : the new amount of reward
            new_guardians (int) : the new amount of guardians

        Complexity:
            Best and worst case: O(logN), where N is the number of land sites.
            Explanation:
            - Scenario 1: when the element is at the root node:
                Complexity : O(1 + 2logN)
            - Scenario 2: when the element is at the leaf node:
                Complexity: O(3logN)
            - By considering both cases, the dominating term is O(logN) which results in same complexity in best and worst case.
            - The BST operation involves are search, delete and insert which either takes constant time operation or logN.
        """
        # search for the particular node
        # best:O(1) when the element is at the root node, worst:O(logN) when the element is at the leaf
        land = self.sites[land.get_ratio()]

        # delete the node   best/worst:O(log N)
        self.sites.__delitem__(land.get_ratio())
        land.set_guardians(new_guardians)
        land.set_gold(new_reward)

        # insert the node   best/worst:O(log N)
        self.sites[land.get_ratio()] = land

