"""
This module consists of PokeTeam class and Trainer class with its own functions and methods implemented.
All the instance variables are instantiated with suitable ADT provided in data structure files
"""

__author__ = "Chew Yang Xuan"

from pokemon import *
import random
from typing import List
from battle_mode import BattleMode
from data_structures.bset import BSet
from data_structures.stack_adt import ArrayStack
from data_structures.queue_adt import CircularQueue
from data_structures.array_sorted_list import ArraySortedList
from data_structures.sorted_list_adt import ListItem

class PokeTeam:
    """
    PokeTeam class represents a team of pokemon that is used for battle purpose.

    Attributes:
        TEAM_LIMIT: The maximum number of a team limit
        POKE_LIST: A list which contains all the pokemon
        CRITERION_LIST: A list which contains all the criteria
        team: An ArrayR which contains all the Pokemon object
        battle_team: Based on the battle mode assigning to the suitable data structure, used in battle purpose
        regen_team: used for regeneration purpose which store a fixed size tuple
        team_count: An integer counter which records the number of pokemon in a list
        special_method_call: A boolean value which use to indicate whether special method is called
    """
    TEAM_LIMIT = 6
    POKE_LIST = get_all_pokemon_types()
    CRITERION_LIST = ["health", "defence", "battle_power", "speed", "level"]

    def __init__(self):
        """
        Initialise a PokeTeam instance.
        :complexity:
            Best and Worst Case: O(L), when L is the TEAM_LIMIT
        """
        self.team = ArrayR(self.TEAM_LIMIT)
        self.battle_team = None
        self.regen_team = ArrayR(self.TEAM_LIMIT)
        self.team_count = 0
        self.special_method_call = False
        self.special_call_times = 0

    def choose_manually(self) -> None:
        """
        A method which provide a user interface to allow user to choose their pokemons manually. It allows user to
        type the numbers which indicating different pokemon and add to their team. Users are able to stop choosing at
        any time as long as they enter 0.
        : complexity:
            Best: O(1) when the user type 0 to quit the loop without entering any pokemon.
            Worst: O(N) where N is the number of user input as it will iterate through N times the user.
        """

        # continue iterate until it reaches the team limit
        while self.team_count != self.TEAM_LIMIT:
            # allow user to enter number
            input_choice = input("Type numbers between 1 to 77 to choose the pokemon. To quit the program, "
                                 "enter '0'.\n")
            # raise ValueError if the user does not enter a number
            try:
                input_choice = int(input_choice)
                # retrieve the pokemon object and add into the team
                if input_choice != 0 and input_choice <= len(self.POKE_LIST):
                    pokemon_obj = self.POKE_LIST[input_choice - 1]
                    pokemon_ins = pokemon_obj()  # create an instance of the class
                    self.team[self.team_count] = pokemon_ins
                    self.team_count += 1

                # break the loop when 0 is entered
                elif input_choice == 0:
                    break

                # print error sentence when invalid number is enter
                elif input_choice > len(self.POKE_LIST):
                    print("The number is out of range. Try again.")
            except ValueError:
                print("Invalid input. Only numbers are accepted")

    def choose_randomly(self) -> None:
        """
        A method which will automatically choose pokemon for the team by using random function
        : complexity:
            Best: O(1 * randint) when there the team.limit = 1, indicating there is only one pokemon
            Worst: O(N * randint) where N is the team.limit, the number of pokemon in the team
        """
        all_pokemon = get_all_pokemon_types()
        self.team_count = 0
        for i in range(self.TEAM_LIMIT):
            rand_int = random.randint(0, len(all_pokemon) - 1)
            self.team[i] = all_pokemon[rand_int]()
            self.team_count += 1

    def regenerate_team(self, battle_mode: BattleMode, criterion: str = None) -> None:
        """
        A method which heal all pokemon to their original HP while preserving their level and evolution
        based on the battle mode.
        Args:
            battle_mode: BattleMode (Set, Rotate, Optimise)
            criterion: used for optimise mode
        :complexity:
            SET and ROTATE Mode:
                Best: O(N^2 * isinstance()).
                    N is the number of pokemon in the team before send to battle.
                    When the team does not have repeating pokemons and all the pokemons are dead after battle.

                Worst: O(N^3 * isinstance() * M^2).
                    N is the number of pokemon in the team before send to battle. M is the size of the evolution line.
                    Occurs when the team sent to battle wins and all the pokemons are still alive after the battle.
                    There might also be repeating pokemons.

            OPTIMISE Mode:
                Best: O(N^2 * isinstance()). N is the number of pokemon in the team before send to battle.
                    Occurs when the team does not have repeating pokemons and all the pokemons are dead after battle.
                    All the pokemon would also have the same value of the criterion used to make comparison on
                    the sequence.

                Worst: O(N^3 * isinstance() * M^2 * logP).
                    N is the number of pokemon in the team before send to battle. M is the size of the evolution line.
                    P is the length of the pokedex.
                    Occurs when the team sent to battle wins and all the pokemons are still alive after the battle.

        """

        if battle_mode == BattleMode.SET or battle_mode == BattleMode.ROTATE:
            temp_storage = ArrayR(self.team_count)
            self.regenerate_set_rotate_optimise(temp_storage)
            self.restore_team(temp_storage, battle_mode)

        elif battle_mode == BattleMode.OPTIMISE:
            temp_storage = ArraySortedList(self.team_count)
            self.regenerate_set_rotate_optimise(temp_storage, criterion)
            self.restore_team(temp_storage, battle_mode)


    def regenerate_set_rotate_optimise(self, temp_storage: ArrayR| ArraySortedList, criterion: str = None) -> None:
        """
        A method which perform regeneration for three battle modes by making two comparison.
        Args:
            temp_storage: a temporary variable to store all the regenerated pokemon
            criterion: used for optimise mode

        :complexity:
            SET and ROTATE Mode:

                Best: O(N^2 * isinstance()). N is the number of pokemon in the team before send to battle.
                    When the team does not have repeating pokemons and all the pokemons are dead after battle
                Worst: O(N^3 * isinstance() * M^2).
                    N is the number of pokemon in the team before send to battle. M is the size of the evolution line.
                    Occurs when the team sent to battle wins and all the pokemons are still alive after the battle.
                    There might also be repeating pokemons.

            OPTIMISE Mode:
                Best: O(N^2 * isinstance()). N is the number of pokemon in the team before send to battle.
                    Occurs when the team does not have repeating pokemons and all the pokemons are dead after battle.
                    All the pokemon would also have the same value of the criterion used to make comparison on
                    the sequence.

                Worst: O(N^3 * isinstance() * M^2 * logP).
                    N is the number of pokemon in the team before send to battle. M is the size of the evolution line.
                    P is the length of the pokedex.
                    Occurs when the team sent to battle wins and all the pokemons are still alive after the battle.

        """
        for i in range(self.team_count):      # O(N)
            pokemon_tuple = self.regen_team[i]
            pokemon_obj = pokemon_tuple[0]
            pokemon_name = pokemon_tuple[1]
            ori_hp = pokemon_tuple[2]

            # deal with repeated pokemon
            if self.team_count >= 2:
                for z in range(self.team_count):  # O(N * isinstance())
                    pokemon_item = temp_storage[z]
                    if isinstance(pokemon_item, ListItem):
                        pokemon = pokemon_item.value
                    else:
                        pokemon = pokemon_item

                    if pokemon is None:
                        break
                    elif pokemon_name in pokemon.evolution_line:    # O(M) M is the size of the evolution line
                        self.restore_pokemon(temp_storage, pokemon_obj, ori_hp, i, criterion)   # O(1)
                        break

            # dead pokemon
            if pokemon_obj.health <= 0:
                self.restore_pokemon(temp_storage, pokemon_obj, ori_hp, i, criterion)   # O(1)
            else:
                # compare with the pokemon that are still alive -- restore their health
                for x in range(self.team_count):
                    battled_pokemon_item = self.team[x]
                    if isinstance(battled_pokemon_item, ListItem):
                        battled_pokemon = battled_pokemon_item.value
                    else:
                        battled_pokemon = battled_pokemon_item

                    if battled_pokemon is None:
                        continue
                    else:
                        if pokemon_name in battled_pokemon.evolution_line:   # O(M) M is the size of the evolution line
                            self.restore_pokemon(temp_storage, battled_pokemon, ori_hp, i, criterion)   # O(1)
                            break


    def restore_pokemon(self, temp_storage: ArrayR | ArraySortedList, pokemon:Pokemon, ori_hp: int, i: int,
                        criterion: str = None) -> None:
        """
        A method which restore the pokemon health and place them in temp_storage.
        Args:
            temp_storage: the temporary storage for the regenerated pokemon
            pokemon: pokemon object
            ori_hp: original health value
            i: the index to be added in the temp_storage
            criterion: used for the optimise battle mode

        : complexity:
        ArrayR:
            Best and Worst case O(1). Assign value takes constant operation.

        ArraySortedList:
            Best: O(m), m is the size of the pokemon's key value that being compared
            Occurs when the item added into the temp_storage matches the key value with the middle item
            in the sorted list. It will return the index and run the loop once.

            Worst: O(m * logN), m is the size of the pokemon's key value that being compared and
            N is the length of the pokedex list.
            Occurs when the item is at one of the extremes (front or end of the list)
        """
        if isinstance(temp_storage, ArrayR):
            pokemon.health = ori_hp
            temp_storage[i] = pokemon
        else:
            pokemon.health = ori_hp
            key = self.get_key(pokemon, criterion)
            if (self.special_call_times % 2) != 0:
                key *= -1
            item = ListItem(pokemon, key)
            temp_storage.add(item)

    def restore_team(self, temp_storage: ArrayR | ArraySortedList, battle_mode: BattleMode) -> None:
        """
        A method which will restore back all the pokemon in the temporary storage into their team and battle team.
        Args:
            temp_storage: the temporary storage for the regenerated pokemon
            battle_mode: BattleMode (Set, Rotate, Optimise)
        : complexity:
            For all battle mode:
                O(N) for best and worst case. N represents the length of the list with the restored pokemon.
                No matter it regenerated in any mode, the difference is only the sequence, and there is no
                early termination condition set to differentiate between both cases.

        """
        self.battle_team.clear()

        # battle mode rotate
        if isinstance(self.battle_team, CircularQueue):

            # regenerated team in different battle mode
            if isinstance(temp_storage, ArraySortedList):   # Optimise Mode
                for y in range(len(temp_storage)):
                    self.battle_team.append(temp_storage[y].value)
                    self.team[y] = temp_storage[y].value

            elif isinstance(temp_storage, ArrayR):
                if battle_mode == BattleMode.SET:   # Set Mode
                    temp_i = self.team_count - 1
                    for y in range(len(temp_storage)):
                        pokemon = temp_storage[y]
                        self.battle_team.append(pokemon)
                        self.team[temp_i] = pokemon
                        temp_i -= 1

                elif battle_mode == BattleMode.ROTATE:  # Rotate Mode
                    for y in range(len(temp_storage)):
                        pokemon = temp_storage[y]
                        self.battle_team.append(pokemon)
                        self.team[y] = pokemon

        # battle mode Set
        elif battle_mode == BattleMode.SET:
        # regenerated team in different battle mode
            temp_var = ArrayStack(len(temp_storage))
            for y in range(len(temp_storage)):
                pokemon = temp_storage[y]
                temp_var.push(pokemon)
                self.team[y] = pokemon

            for x in range(len(temp_var)):
                pokemon = temp_var.pop()
                self.battle_team.push(pokemon)

        # battle mode Optimise
        elif battle_mode == BattleMode.OPTIMISE:
            for y in range(len(temp_storage)):
                pokemon = temp_storage[y]
                self.battle_team[y] = pokemon
                self.team[y] = pokemon.value

    def assign_team(self, criterion: str = None) -> None:
        """
        A method which place the pokemon battle team in ArraySortedList ADT when the battle mode Optimise is called.
        Args:
            criterion: a string which determine the key value to sort by based on the criterion list

        : complexity:
            Best: O(N log N) when N is the length of self.team (represented by team_count).
            Occurs when the item is always added at the last position.

            Worst: O(N^2) when N is the length of the self.team (represented by team_count).
            Occurs when the item is always added at the first position.
        """

        temp_team = ArrayR(self.team_count)
        self.battle_team = ArraySortedList(self.team_count)

        # iterate through the index of self.team and determine the key value based on the argument
        for i in range(self.team_count):
            if self.team[i] is not None:
                pokemon = self.team[i]
                key = self.get_key(pokemon, criterion)

                # create a ListItem object which consist of the pokemon and the key
                item = ListItem(pokemon, key)
                # add to the team in the correct sorted position
                self.battle_team.add(item)

        # the loop takes O(N)
        # update the self.team with the correct sequence after the battle team is sorted.
        for i in range(len(self.battle_team)):
            temp_team[i] = self.battle_team[i].value

        self.team = temp_team
        self.create_copy_team()     # O(N)

    def assemble_team(self, battle_mode: BattleMode) -> None:
        """
        A method which place the pokemon battle team in suitable ADT when the battle mode Set and Rotate is call.
        For Set battle mode, ArrayStack ADT. For Rotate battle mode, Circular Queue ADT.
        Args:
            battle_mode: either set or rotate battle mode

        :complexity:
        SET mode:
            Best and worst case: O(N), where N is the length of the self.team. This refers to iterating through the list
            and push the pokemon into the battle team. Push method in ArrayStack takes O(1)

        ROTATE mode:
            Best and worst case: O(N), where N is the length of the self.team. This refers to iterating through the list
            and append the pokemon into the battle team. Append method in CircularQueue takes O(1)
        """
        # create a temporary team to store the pokemon accordingly
        temp_team = ArrayR(self.team_count)

        if battle_mode == BattleMode.SET:
            self.battle_team = ArrayStack(self.team_count)   # O(N)
            # accessing the last index in the team
            temp_i = self.team_count - 1

            # iterate through the team and add the pokemon
            for i in range(self.team_count):     # O(N)
                if self.team[i] is not None:
                    self.battle_team.push(self.team[i])
                    temp_team[temp_i] = self.team[i]
                    temp_i -= 1   # add backwards from the last position to the first (LIFO)

        elif battle_mode == BattleMode.ROTATE:
            self.battle_team = CircularQueue(self.team_count)

            # iterate through the team and add the pokemon into the team
            for i in range(self.team_count):
                if self.team[i] is not None:
                    self.battle_team.append(self.team[i])
                    temp_team[i] = self.team[i]

        self.team = temp_team
        self.create_copy_team()     # O(N)

    def special(self, battle_mode: BattleMode) -> None:
        """
        A method which rearrange the team sequence based on different battle mode.
        Args:
            battle_mode: Set, Rotate or Optimise battle mode

        Returns: None
        : complexity:
            For all battle mode:
            O(N^2) for best and worst case. N represents the length of the self.team (represented by team_count)
            There is no early termination occurs in any battle mode, iterating through the whole list is
            required at any condition.

        """
        self.special_method_call = True
        self.special_call_times += 1
        # Set mode require to reverse the first half of the team
        if battle_mode == BattleMode.SET:
            temp_queue = CircularQueue(self.team_count)
            self.special_set(temp_queue)

        # Rotate mode requires to reverse the bottom half of the team
        elif battle_mode == BattleMode.ROTATE:
            # create temporary stack and queue to store upper and bottom half of the team
            temp_queue = CircularQueue(self.team_count)
            temp_stack = ArrayStack(self.team_count)
            self.special_rotate(temp_queue, temp_stack)

        # Optimise mode toggles the sorting order from ascending to descending and vice versa
        elif battle_mode == BattleMode.OPTIMISE:
            temp_sort_list = ArraySortedList(self.team_count)
            self.special_optimise(temp_sort_list)

        self.create_copy_team()

    def special_set(self, temp_queue: CircularQueue):
        """
        A method which reverse the first half of the team
        Args:
            temp_queue: a temporary variable which store the first half of the team

        :complexity:
            Best and worst case: O(N) when N is the length of the self.team (represented by team_count)

        """
        # iterate the half of the team and store in a temporary queue

        for _ in range(math.ceil(self.team_count / 2)):
            pokemon = self.battle_team.pop()
            print(pokemon)
            temp_queue.append(pokemon)

        # add into the correct position by calculating the first half of the team
        i = int(self.team_count / 2) - 1

        # add into battle team and team accordingly
        while not temp_queue.is_empty():
            pokemon = temp_queue.serve()
            self.battle_team.push(pokemon)
            self.team[i] = pokemon
            i -= 1

    def special_rotate(self, temp_queue: CircularQueue, temp_stack: ArrayStack):
        """
        A method which reverse the bottom half of the team
        Args:
            temp_queue: a temporary variable which store the bottom half of the team
            temp_stack: a temporary variable which store the first half of the team

        :complexity:
            Best and worst case: O(N) when N is the length of the self.team (represented by team_count)

        """
        # iterate through and store the bottom half into the queue
        for _ in range(math.ceil(self.team_count / 2)):
            pokemon = self.battle_team.serve()
            temp_queue.append(pokemon)

        # iterate through and store the upper half into the stack
        for _ in range(math.ceil(self.team_count / 2)):
            pokemon = self.battle_team.serve()
            temp_stack.push(pokemon)

        i = 0
        # added back to the team accordingly
        while not temp_queue.is_empty():
            pokemon = temp_queue.serve()
            self.battle_team.append(pokemon)
            self.team[i] = pokemon
            i += 1

        while not temp_stack.is_empty():
            pokemon = temp_stack.pop()
            self.battle_team.append(pokemon)
            self.team[i] = pokemon
            i += 1

    def special_optimise(self, temp_sort_list: ArraySortedList):
        """
        A method that toggles the sorting order (from ascending to descending and vice-versa)
        Args:
            temp_sort_list: a temporary variable which store the sorted list

        :complexity:
            Best: O(N log N) when N is the length of self.team (represented by team_count).
            Occurs when the item is always added at the last position.

            Worst: O(N^2) when N is the length of the self.team (represented by team_count).
            Occurs when the item is always added at the first position.
        """

        # in order to arrange in alternate order, change the key value to negative
        for i in range(self.team_count):
            item = self.battle_team[i]
            item.key *= -1
            temp_sort_list.add(item)

        # update the sequence in battle team and team
        for i in range(len(temp_sort_list)):
            self.battle_team[i] = temp_sort_list[i]
            self.team[i] = temp_sort_list[i].value

    def create_copy_team(self) -> None:
        """
        A method which create a copy of the team manually and store them in self.regen_team before they send to battle.
        The element store in self.regen_team wil be in the form of tuple with size of 3

        : complexity
        Best and worst case: O(N) where N is the length of the team. No condition occurs to break the loop results in
        same complexity for both case.
        """
        # if put in tuple, the health will not be updated
        for i in range(self.team_count):
            pokemon_item = self.team[i]
            if isinstance(pokemon_item, ListItem):
                pokemon = pokemon_item.value
            else:
                pokemon = pokemon_item

            if pokemon is not None:
                self.regen_team[i] = (pokemon, pokemon.name, pokemon.health)

    def get_key(self, pokemon: Pokemon, criterion: str) -> int:
        """
        A method to retrieve the key value based on the criterion
        Args:
            pokemon: Pokemon
            criterion: the criterion needed for sorting
        Returns: integer value based on the criterion

        :complexity:
        Best and worst case: O(comp==)

        """
        if criterion == "health":
            return pokemon.health
        elif criterion == "defence":
            return pokemon.defence
        elif criterion == "battle_power":
            return pokemon.battle_power
        elif criterion == "speed":
            return pokemon.speed
        elif criterion == "level":
            return pokemon.level

    def __getitem__(self, index: int):
        """
        Retrieves the pokemon at the specific index
        Args:
            index: the index of the pokemon to retrieve

        Returns: the pokemon object at the specified index
        : complexity:
            Best: O(1) when the team does not have any none element and the item is at the index 0 of the team.
            Worst: O(N) when the team have none elements or the item is at the end of the team, N represents the length
                    of the team
        """
        count = 0
        i = 0
        # iterate through the length of self.team
        while i < self.team_count:
            # check if the element is none
            if self.team[i] is not None:
                if count == index:
                    return self.team[i]
                count += 1
            i += 1
        raise IndexError("Index out of range")

    def __len__(self) -> int:
        """
        Returns the number of pokemon in the team. Only include not None value
        Returns: the number of pokemon in the team

        : complexity:
        Best and worst case: O(N) where N represents the length of the team
        As it will iterate through the team in any condition to calculate the length of the team
        """
        count = 0
        for i in range(len(self.team)):
            if self.team[i] is not None:
                count += 1
        return count

    def __str__(self):
        """
        Returns a spring representation of the PokeTeam object
        Returns: A string representation of all the PokeTeam object
        : complexity:
            Best and worst case: O(N) where N represents the length of the team
            As it will iterate through the team in any condition to calculate the length of the team
        """
        poke_team = ""
        for i in range(self.team_count):
            poke_team += str(self.team[i]) + "\n"
        return poke_team


class Trainer:
    """
    Represents a trainer to fight the game.

    Attributes:
        - name: the name of the trainer
        - poke_team: the poketeam of the trainer
        - pokedex: records all the type of the pokemon seen and available

    """

    def __init__(self, name: str = "Default") -> None:
        """
        Initialise a Trainer instance.
        : complexity:
            Best and Worst case would both be O(N), N is the TEAM_LIMIT
        """
        self.name = name
        self.poke_team = PokeTeam()
        self.pokedex = BSet()

    def pick_team(self, method: str) -> None:
        """
        A method that pick a team based on the mood (random or manual)
        : complexity:
            if choose randomly
            Best: O(1 * randint()), which is the best case of choose_randomly().
                  The updating pokedex loop will only run for a loop, indicating O(1)
            Worst: O(N * randint()),  which is the worst case of choose_randomly()
                   The updating pokedex loop will only run for N times of loop, indicating O(N).
                    N indicates the length of the team, the numbers of pokemon in the team

            if choose manually:
            Best and worst case O(N), which is the worst case of choose_manually().
            The updating pokedex loop will only run for N times of loop, indicating O(N).
            N indicates the length of the team, the numbers of pokemon in the team
        """
        if method.upper() == "RANDOM":
            self.poke_team.choose_randomly()
        elif method.upper() == "MANUAL":
            self.poke_team.choose_manually()
        else:
            raise NameError("Invalid method.")

        # update the pokedex with the pokemon in the team
        for index in range(len(self.poke_team)):
            pokemon = self.poke_team[index]
            self.pokedex.add(pokemon.get_poketype().value + 1)  # O(1)
            # added one as the enum starts with 1

    def get_team(self) -> PokeTeam:
        """
        A method which returns the pokemon team
        Returns: PokeTeam
        : complexity: O(1) for best and worst case
        """
        return self.poke_team

    def get_name(self) -> str:
        """
        A method which returns the name of the trainer's name
        Returns: trainer's name
        : complexity: O(1) for best and worst case
        """
        return self.name

    def register_pokemon(self, pokemon: Pokemon) -> None:
        """
        A method which register a pokemon by its Poketype as seen on the trainer's pokedex
        Args:
            pokemon: pokemon seen
        : complexity:
            Best and worst case: O(1).
        """
        self.pokedex.add(pokemon.get_poketype().value + 1)

    def get_pokedex_completion(self) -> float:
        """
        A method that calculate the pokedex completion.
        Returns: the rounded float ratio
        : complexity:
            Best and worst case: O(|elems|) which |elems| refers to the number of bits which use to represent the
            different poketype.
        """
        return round(len(self.pokedex) / len(PokeType), 2)

    def __str__(self) -> str:
        """
        Returns a spring representation of the trainer object
        Returns: trainer's name and its pokedex completion
        : complexity:
            Best and worst case: O(|elems|) which |elems| refers to the number of bits which use to represent the
            different poketype.
        """
        completion = int(self.get_pokedex_completion() * 100)
        return f"Trainer {self.name} Pokedex Completion: {completion}%"


if __name__ == '__main__':
    t = Trainer('Ash')
    t.pick_team("random")
    print(t.get_team().regenerate_team(BattleMode.SET))
    print(len(t.get_team()))



