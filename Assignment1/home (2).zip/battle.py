"""
This module consists of Battle class with its own functions and methods implemented.
All the instance variables are instantiated with suitable ADT provided in data structure files
"""
from __future__ import annotations

__author__ = "Chew Yang Xuan"

import math
from pokemon import *
from poke_team import Trainer, PokeTeam
from typing import Tuple
from battle_mode import BattleMode
from data_structures.stack_adt import ArrayStack
from data_structures.queue_adt import CircularQueue
from data_structures.sorted_list_adt import ListItem
from data_structures.array_sorted_list import ArraySortedList


class Battle:
    """
    Battle class represents a battle between two trainers for different battle modes.

    Attributes:
        trainer_1 (Trainer): The first trainer in the battle
        trainer_2 (Trainer): The second trainer in the battle
        battle_mode (BattleMode): The mode of the battle (Set , Rotate or Optimise)
        criterion (str): the criterion used for sorting team in optimise mode.
    """

    def __init__(self, trainer_1: Trainer, trainer_2: Trainer, battle_mode: BattleMode, criterion="health") -> None:
        """
        A method which initialise the battle object
        Args:
            trainer_1 (Trainer): The first trainer in the battle
            trainer_2 (Trainer): The second trainer in the battle
            battle_mode (BattleMode): The mode of the battle (Set , Rotate or Optimise)
            criterion (str): the criterion used for sorting team in optimise mode.
        """
        self.trainer_1 = trainer_1
        self.trainer_2 = trainer_2
        self.battle_mode = battle_mode
        self.criterion = criterion

    def commence_battle(self) -> Trainer | None:
        """
        A method which commence the battle based on the battle mode set.
        Returns:
            winner team or None which indicates draw in both team

        :complexity:
            :see:
                SET mode: #set_battle()
                ROTATE mode: #rotate_battle()
                OPTIMISE mode: #optimise_battle()
        """
        win_team = None
        if self.battle_mode == BattleMode.SET:
            win_team = self.set_battle()
        elif self.battle_mode == BattleMode.ROTATE:
            win_team = self.rotate_battle()
        elif self.battle_mode == BattleMode.OPTIMISE:
            win_team = self.optimise_battle()

        if win_team == self.trainer_1.poke_team.team:
            return self.trainer_1
        elif win_team == self.trainer_2.poke_team.team:
            return self.trainer_2
        else:
            return None

    def _create_teams(self, method: str = "random") -> None:
        """
        A method which create a team of pokemon and assemble them into suitable ADT based on battle mode
        Args:
            method: the method use to pick the pokemon (random or manual)

        : complexity:
        SET mode:
            Best and worst case: O(N), where N is the length of the team. This refers to iterating through the list
            and push the pokemon into the battle team. Push method in ArrayStack takes O(1)

        ROTATE mode:
            Best and worst case: O(N), where N is the length of the team. This refers to iterating through the list
            and append the pokemon into the battle team. Append method in CircularQueue takes O(1)

        OPTIMISE mode:
            Best: O(1)
            Occurs when only one item added into the battle_team and it matches the key value with the middle item
            in the sorted list. It will return the index and run the loop once.

            Worst: O(N^2), N is the length of the team. Occurs when the length of battle_team is > 1 and the item
            added into the team would be place at the end of the team. This requires more iteration
        """
        self.trainer_1.pick_team(method)
        self.trainer_2.pick_team(method)

        if self.battle_mode == BattleMode.SET or self.battle_mode == BattleMode.ROTATE:
            self.trainer_1.poke_team.assemble_team(self.battle_mode)
            self.trainer_2.poke_team.assemble_team(self.battle_mode)

        elif self.battle_mode == BattleMode.OPTIMISE:
            self.trainer_1.poke_team.assign_team(self.criterion)
            self.trainer_2.poke_team.assign_team(self.criterion)

    # Note: These are here for your convenience
    # If you prefer you can ignore them
    def set_battle(self) -> PokeTeam | None:
        """
        A method which commences a battle in SET mode.
        Returns: A win pokemon team or None which indicates draw
        : complexity:

        Best: O(MN), where
            M indicates the minimum health values of pokemon and
            N indicates the number of pokemon in the battle team.

            Occurs when there is a minimum iteration of the loop due to minimum health values on the pokemons in battle
            team of the both trainers. The pokemon type of the both battling pokemons should already present at each
            other pokedex. The battling pokemons should also have the minimum health value which ensures one of the
            pokemon wins after one execution of battle.

        Worst: O(M * N^3 * P^2), where
            M indicates the maximum health values of pokemon and
            N indicates the number of pokemon in the battle team.
            P indicates the length of the original self.team (before battle).

            Occurs when there is a maximum iteration of the loop due to maximum health values on the pokemons in battle
            team of the both trainers.The pokemon type of the both battling pokemons should not be in each other
            pokedex. After the execution of the battle, one team will become empty while winning team does not lose any
            pokemons after battling in every round.

        """
        team_1 = self.trainer_1.get_team().battle_team
        team_2 = self.trainer_2.get_team().battle_team

        while not team_1.is_empty() and not team_2.is_empty():  # w:O(NM)
            pokemon_1 = team_1.peek()   # O(1)
            pokemon_2 = team_2.peek()   # O(1)

            # check and update pokedex completion
            self.trainer_1.register_pokemon(pokemon_2)  # w:O(N)
            self.trainer_2.register_pokemon(pokemon_1)  # w:O(N)

            result = self.battle_logic(pokemon_1, pokemon_2)
            # result referring to those who are still alive
            if result == pokemon_1:
                team_2.pop()
            elif result == pokemon_2:
                team_1.pop()
            elif result == [pokemon_1, pokemon_2]:
                continue

        return self.check_winning_team(team_1, team_2)  # w: O(P^2)

    def rotate_battle(self) -> PokeTeam | None:
        """
        A method which commences a battle in ROTATE mode.
        Returns: A win pokemon team or None which indicates draw

        :complexity:
        Best: O(NM), where
        M indicates the minimum health values of pokemon and
        N indicates the number of pokemon in the battle team.

        Occurs when there is a minimum iteration of the loop due to minimum health values on the pokemons in battle
        team of the both trainers. The pokemon type of the both battling pokemons should already present at each other
        pokedex. The battling pokemons should also have the minimum health value which ensures one of the pokemon
        wins after one execution of battle.

        Worst: O(M * N^4 * P), where
        M indicates the maximum health values of pokemon and
        N indicates the number of pokemon in the battle team and
        P indicates the length of the original self.team (before battle).

        Occurs when there is a maximum iteration of the loop due to maximum health values on the pokemons in battle team
        of the both trainers. The pokemon type of the both battling pokemons should not be in each other pokedex. After
        the execution of the battle, one team will become empty while winning team does not lose any pokemons after
        battling in every round.

        """
        # fight a round - send back to team - next pokemon fight

        team_1 = self.trainer_1.get_team().battle_team
        team_2 = self.trainer_2.get_team().battle_team

        while not team_1.is_empty() and not team_2.is_empty():  # w:O(NM)
            pokemon_1 = team_1.serve()
            pokemon_2 = team_2.serve()

            # check and update pokedex completion
            self.trainer_1.register_pokemon(pokemon_2)  # w:O(N)
            self.trainer_2.register_pokemon(pokemon_1)  # w:O(N)

            result = self.battle_logic(pokemon_1, pokemon_2)
            # result referring to those who are still alive
            if result == pokemon_1:
                team_1.append(pokemon_1)
            elif result == pokemon_2:
                team_2.append(pokemon_2)
            elif result == (pokemon_1, pokemon_2):
                team_1.append(pokemon_1)
                team_2.append(pokemon_2)

        return self.check_winning_team(team_1, team_2)  # w:O(NP)

    def optimise_battle(self) -> PokeTeam | None:
        """
        A method which commences a battle in OPTIMISE mode.
        Returns: A win pokemon team or None which indicates draw

        :complexity:

        Best: O(getattr()^2 * NM), where M indicates the minimum health values of pokemon and
            N indicates the number of pokemon in the battle team.
            Occurs when there is a minimum iteration of the loop due to minimum health values on the pokemons in battle
            team of the both trainers. The pokemon type of the both battling pokemons should already present at each
            other pokedex. The battling pokemons should also have the minimum health value which ensures one of the
            pokemon wins after one execution of battle.

        Worst: O(M * N^4 * P * getattr()^2), where M indicates the maximum health values of pokemon and
            N indicates the number of pokemon in the battle team and
            P indicates the length of the original self.team (before battle).
            Occurs when there is a maximum iteration of the loop due to maximum health values on the pokemons in battle
            team of the both trainers. The pokemon type of the both battling pokemons should not be in each other
            pokedex. After the execution of the battle, one team will become empty while winning team does not lose
            any pokemons after battling in every round.
        """
        # sorted list
        team_1 = self.trainer_1.get_team().battle_team
        team_2 = self.trainer_2.get_team().battle_team

        while not team_1.is_empty() and not team_2.is_empty():  # w:O(NM)
            pokemon_1 = team_1.delete_at_index(0).value
            pokemon_2 = team_2.delete_at_index(0).value

            # check and update pokedex completion
            self.trainer_1.register_pokemon(pokemon_2)
            self.trainer_2.register_pokemon(pokemon_1)

            result = self.battle_logic(pokemon_1, pokemon_2)

            key1 = getattr(pokemon_1, self.criterion)   # w:O(getattr())
            key2 = getattr(pokemon_2, self.criterion)   # w:O(getattr())

            # check the team whether special method is call
            if self.trainer_1.get_team().special_method_call:
                key1 *= -1
            elif self.trainer_2.get_team().special_method_call:
                key2 *= -1

            item1 = ListItem(pokemon_1, key1)
            item2 = ListItem(pokemon_2, key2)

            # result referring to those who are still alive
            if result == pokemon_1:
                team_1.add(item1)
            elif result == pokemon_2:
                team_2.add(item2)
            elif result == (pokemon_1, pokemon_2):
                team_1.add(item1)
                team_2.add(item2)

        return self.check_winning_team(team_1, team_2)  # w:O(NP)

    def battle_logic(self, p1: Pokemon, p2: Pokemon) -> Pokemon | None:
        """
        A method which involves the battle logic between two pokemons by comparing the speed.
        Returns: The winning pokemon or None which indicates draw

        : complexity:
        Best: O(1) which occurs when the both trainers have all same poketype of pokemon in their pokedex.
                When both pokemons are sent to battle they can either:
                    (a) still alive after battle and remain alive after losing the hp
                    (b) fainted after battle

        Worst: O(N + M) where
                N is the number of different poketype in the trainer's 1 pokedex.
                M is the number of different poketype in the trainer's 2 pokedex.

                When both pokemons are sent to battle they can either:
                    (a) still alive after battle and one of them fainted after losing the hp
                    (b) one of the pokemon fainted after the battle
        """
        t1 = self.trainer_1
        t2 = self.trainer_2

        if p1.get_speed() > p2.get_speed():
            # p1 attack , p2 defend
            attack_damage = self.computing_damage(p1, p2, t1, t2)
            p2.defend(attack_damage)

            if p2.health > 0:
                attack_damage = self.computing_damage(p2, p1, t2, t1)
                p1.defend(attack_damage)

        elif p2.get_speed() > p1.get_speed():
            # p2 attack, p1 defend
            attack_damage = self.computing_damage(p2, p1, t2, t1)
            p1.defend(attack_damage)

            if p1.health > 0:
                attack_damage = self.computing_damage(p1, p2, t1, t2)
                p2.defend(attack_damage)

        elif p1.get_speed() == p2.get_speed():
            # p1 attack, p2 defend
            attack_damage = self.computing_damage(p1, p2, t1, t2)
            p2.defend(attack_damage)

            # p2 attack, p1 defend
            attack_damage = self.computing_damage(p2, p1, t2, t1)
            p1.defend(attack_damage)

        # after first round of attack check if any pokemon fainted
        return self.computing_health(p1, p2)

    def computing_damage(self, p1:Pokemon, p2:Pokemon, t1: Trainer, t2: Trainer) -> int:
        """
        A method which computes and calculate the damage between both pokemon
        Args:
            p1: pokemon 1 involve in battle
            p2: pokemon 2 involve in battle
            t1: trainer 1 which have pokemon 1 in its team
            t2: trainer 2 which have pokemon 2 in its team

        Returns: the attack damage in integer
        :complexity:
            Best: O(1) which occurs when the trainer have only one pokemon type in its pokedex
            Worst: O(|elems|) which |elems| refers to the number of bits which use to represent the different poketype.
                   Occurs when the trainer have a maximum number of different poketype

        """
        attack_damage = p1.attack(p2) * (t1.get_pokedex_completion() / t2.get_pokedex_completion())
        return math.ceil(attack_damage)

    def computing_health(self, p1: Pokemon, p2: Pokemon) -> tuple[Pokemon, Pokemon] | Pokemon | None:
        """
        A method which updates the pokemon's health after the initial attack by de
        Args:
            p1: first pokemon in the battle
            p2: second pokemon in the battle

        Returns:
            surviving pokemon, can be either one or both (in tuple)

        :complexity:
            Best: O(1). Occurs in two conditions:
                    (a) when both pokemon still alive after battle and remain alive after losing the hp
                    (b) when both pokemon fainted after battle

            Worst:
                O(enumerate() * comp==) which is the _evolve method in level_up() function.
                Occurs in following conditions:
                    (a) when both pokemon still alive after battle and one of them fainted after losing the hp
                    (b) if one of the pokemon fainted after the battle

        """
        # if both pokemon still alive, both pokemon lose 1HP
        if p1.health > 0 and p2.health > 0:
            p1.health -= 1
            p2.health -= 1

            # still alive after losing the HP, send back to team
            if p1.health > 0 and p2.health > 0:
                return p1, p2

            elif p1.health <= 0:
                p2.level_up()
                return p2

            elif p2.health <= 0:
                p1.level_up()
                return p1

        else:
            # if both pokemon faint, move on
            if p1.health <= 0 and p2.health <= 0:
                return None

            # if pokemon1 faint, pokemon2 level up and back to the team
            elif p1.health <= 0:
                p2.level_up()
                return p2

            # if pokemon2 faint, pokemon1 level up and back to the team
            elif p2.health <= 0:
                p1.level_up()
                return p1

    def check_winning_team(self, team_1, team_2) -> PokeTeam | None:
        """
        A method which determine the winning team after one or both of the battle team is empty. This method
        also updates the original team so that it aligns with the updated battle team.
        Args:
            team_1: trainer 1 battle team
            team_2: trainer 2 battle team

        Returns: A win pokemon team or None which indicates draw
        : complexity:
            Best: O(1). Occurs when there is a draw in battle
            Worst: O(N * P), N is the length of the self.team (represented by team_count) and
                P is the length of the battle team.
                Occurs when the team wins the battle while no pokemons dead when battle occurs.
        """
        if team_1.is_empty():
            win_team = team_2
        elif team_2.is_empty():
            win_team = team_1
        else:
            win_team = None

        final_team_1 = self.update_original_team(self.trainer_1.get_team())
        final_team_2 = self.update_original_team(self.trainer_2.get_team())

        if win_team == team_1:
            return final_team_1
        elif win_team == team_2:
            return final_team_2
        else:
            return None

    def update_original_team(self, team: PokeTeam) -> PokeTeam:
        """
        A method which update the self.team so that it aligns with the battle team by removing the pokemons
        which have health that are less than or equal 0.
        Args:
            team: trainer's battle team

        Returns: a team with updated pokemon
        : complexity:

        Set Battle Mode (battle_team : ArrayStack)
            Best: O(1), Occurs when there is only one pokemon in the team
            Worst: O(N), N represents the length of the self.team (represented by team_count).
            Occurs when there is a maximum amount of the pokemon in a team.

        Rotate Battle Mode (battle_team: CircularQueue)
            Best: O(1), Occurs when there is only one pokemon in the team and lose the battle resulting in
            there are no pokemons in battle team.

            Worst: O(N * P), N is the length of the self.team (represented by team_count) and
            P is the length of the battle team.
            Occurs when the team wins the battle while no pokemons dead when battle.

        Optimise Battle Mode (battle_team: ArraySortedList)
            Best: O(1), Occurs when there is only one pokemon in the team and lose the battle resulting in
            there are no pokemons in battle team.

            Worst: O(N * P), N is the length of the self.team (represented by team_count) and
            P is the length of the battle team.
            Occurs when the team wins the battle while no pokemons dead when battle occurs.
        """
        # update the original self.team to remove all the pokemons which have health that less than or equal 0
        ori_list = team.team
        team_length = team.team_count

        # the order is still maintained in self.team
        if isinstance(team.battle_team, ArrayStack):
            for i in range(team_length):
                if ori_list[i].health <= 0:
                    ori_list[i] = None

        # the order is different -- empty the battle team in order to restore the value
        elif isinstance(team.battle_team, CircularQueue):
            for i in range(team_length):    # O(N)
                ori_list[i] = None
            if len(team.battle_team) != 0:
                for i in range(len(team.battle_team)):  # O(P)
                    pokemon = team.battle_team.serve()
                    ori_list[i] = pokemon

        elif isinstance(team.battle_team, ArraySortedList):
            for i in range(team_length):    # O(N)
                ori_list[i] = None
            if len(team.battle_team) != 0:
                for i in range(len(team.battle_team)):  # O(P)
                    ori_list[i] = team.battle_team[i].value

        return ori_list

if __name__ == '__main__':
    t1 = Trainer('Ash')
    t2 = Trainer('Gary')
    b = Battle(t1, t2, BattleMode.ROTATE)

    b._create_teams('manual')

    t1.get_team().regenerate_team(BattleMode.ROTATE)
    winner = b.commence_battle()

    if winner is None:
        print("Its a draw")
    else:
        print(f"The winner is {winner.get_name()}")

