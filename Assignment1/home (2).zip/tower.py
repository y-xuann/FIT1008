"""
This module consists of Battle class with its own functions and methods implemented.
All the instance variables are instantiated with suitable ADT provided in data structure files
"""
__author__ = "Chew Yang Xuan"

from poke_team import Trainer, PokeTeam
from enum import Enum
from data_structures.stack_adt import ArrayStack
from data_structures.queue_adt import CircularQueue
from data_structures.array_sorted_list import ArraySortedList
from data_structures.sorted_list_adt import ListItem
from typing import Tuple
import random
from data_structures.referential_array import ArrayR
from battle import *

class BattleTower:
    """
    Battle Tower class initiate a battle between a player (With pokemon team) with a gauntlet of teams of pokemon
    to battle.

    Attributes:
        MIN_LIVES: The minimum number of lives a team can have.
        MAX_LIVES: The maximum number of lives a team can have.
        player: the player's team
        enemy_teams: A list of enemy teams
        player_lives: number of lives remaining for the player
        enemy_lives: A list of number of lives remaining for the player
        enemy_lives_taken: counter for the number of enemy lives taken by the player
        current_enemy_index: index of the current enemy team
        enemy_counts: total number of enemy team
    """
    MIN_LIVES = 1
    MAX_LIVES = 3

    def __init__(self) -> None:
        """
        Initialise the attributes for the BattleTower class.
        :complexity:
            Best and worst case are O(L), L is the TEAM_LIMIT.
        """
        self.player = Trainer()
        self.enemy_teams = None
        self.player_lives = 0
        self.enemy_lives = None
        self.enemy_lives_taken = 0
        self.current_enemy_index = 0
        self.enemy_counts = 0

    # Hint: use random.randint() for randomisation
    def set_my_trainer(self, trainer: Trainer) -> None:
        """
        A method which sets the player team for the battle tower and generate lives for the player
        in between min and max lives attributes.
        Args:
            trainer: the player's team

        : complexity:
            O(randint()) for best and worst case.
        """
        self.player = trainer
        self.player_lives = random.randint(self.MIN_LIVES, self.MAX_LIVES)

    def generate_enemy_trainers(self, num_teams: int) -> None:
        """
        A method which randomly generates enemy teams for the battle tower.
        Args:
            num_teams: The number of enemy teams to generate

        :complexity:
            Best and worst case is O(N * randint()^2 * M)
            N indicates the num_teams. M indicates the length of each pokemon teams (self.team).
            No early termination occurs resulting in same best and worst case.

        """
        self.enemy_teams = CircularQueue(num_teams)
        self.enemy_lives = CircularQueue(num_teams)
        self.enemy_counts = num_teams

        for i in range(num_teams):
            enemy = Trainer()
            enemy.pick_team("Random")
            enemy.get_team().assemble_team(BattleMode.ROTATE)   # O(M)
            live = random.randint(self.MIN_LIVES, self.MAX_LIVES)
            self.enemy_teams.append(enemy)
            self.enemy_lives.append(live)

    def battles_remaining(self) -> bool:
        """
        A method which checks if there are any battles remaining in the Battle Tower.
        Returns:
            bool: True if there are battles remaining, False otherwise

        :complexity:
            Best and worst case: O(1)
        """
        if len(self.enemy_teams) == 0 or self.player_lives == 0:
            return False
        else:
            return True

    def next_battle(self) -> Tuple[Trainer, Trainer, Trainer, int, int]:
        """
        A method which simulates one battle between the player team and the next enemy team
        Returns: Tuple[Trainer, Trainer, Trainer, int, int]: The battle result, player trainer, enemy trainer,
                player lives remaining after the battle, and enemy lives remaining after the battle.

        Best and Worst Case: O((B*O) + X + Y)
                B is the number of pokemon battles that occurs
                O is the complexity of Battle.battle_logic()
                X is number of  chosen pokemon of trainer's team
                Y is the number of chosen of pokemon team

        """
        # check on the index we want
        enemy = self.enemy_teams.serve()
        enemy_live = self.enemy_lives.serve()

        self.player.get_team().regenerate_team(BattleMode.ROTATE)
        enemy.get_team().regenerate_team(BattleMode.ROTATE)

        battle = Battle(self.player, enemy, BattleMode.ROTATE)
        winner = battle.commence_battle()

        if winner is None:
            self.player_lives -= 1
            enemy_live -= 1
        elif winner == self.player:
            enemy_live -= 1
            self.enemy_lives_taken += 1
        else:
            self.player_lives -= 1

        if enemy_live != 0:
            self.enemy_teams.append(enemy)
            self.enemy_lives.append(enemy_live)

        return winner, self.player, enemy, self.player_lives, enemy_live

    def enemies_defeated(self) -> int:
        """
        A method which returns the number of enemy lives taken by the player
        Returns:
            the number of lives taken

        :complexity:
            O(1) for best and worst case
        """
        return self.enemy_lives_taken


